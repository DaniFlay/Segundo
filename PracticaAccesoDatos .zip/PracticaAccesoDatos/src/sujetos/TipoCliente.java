package sujetos;

public enum TipoCliente {
	vip,
	habitual,
	normal
}
