package sujetos;

public class Cliente {
	private int idCliente;
	private String nombre;
	private String apellidos;
	private TipoCliente tipoCliente;
	public TipoCliente getTipoCliente() {
		return tipoCliente;
	}
	public void setTipoCliente(TipoCliente tipoCliente) {
		this.tipoCliente = tipoCliente;
	}
	private int nCompras;
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public int getnCompras() {
		return nCompras;
	}
	public void setnCompras(int nCompras) {
		this.nCompras = nCompras;
	}
	public Cliente(int idCliente, String nombre, String apellidos, TipoCliente tipoCliente, int nCompras) {

		this.idCliente = idCliente;
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.tipoCliente = tipoCliente;
		this.nCompras = nCompras;
	}
	public Cliente() {

	}

	
	
	
}
