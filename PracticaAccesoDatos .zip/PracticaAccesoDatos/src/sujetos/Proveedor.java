package sujetos;

public class Proveedor {
	private int idProveedor;
	private String direccion;
	private String telefono;
	private TipoP tipoP;
	private int incidencias;
	public int getIdProveedor() {
		return idProveedor;
	}
	public void setIdProveedor(int idProveedor) {
		this.idProveedor = idProveedor;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public TipoP getTipoP() {
		return tipoP;
	}
	public void setTipoP(TipoP tipoP) {
		this.tipoP = tipoP;
	}
	public int getIncidencias() {
		return incidencias;
	}
	public void setIncidencias(int incidencias) {
		this.incidencias = incidencias;
	}
	public Proveedor(int idProveedor, String direccion, String telefono, TipoP tipoP, int incidencias) {
		this.idProveedor = idProveedor;
		this.direccion = direccion;
		this.telefono = telefono;
		this.tipoP = tipoP;
		this.incidencias = incidencias;
	}
	public Proveedor() {

	}
	
	

}
