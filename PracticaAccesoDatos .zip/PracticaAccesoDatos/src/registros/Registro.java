package registros;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import archivos.ComparacionArchivos;

public class Registro {

    public static void registroCopia(String rutaArchivoRegistro, File archivo, Path rutaOrigen, Path rutaDestino) {
        try (FileWriter fw = new FileWriter(rutaArchivoRegistro, true)) {
            fw.write(archivo.getName() + " copiado de " + rutaOrigen.toString() + " a " + rutaDestino.toString() + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static boolean registroBorrado(Path rutaDestino) {
        String nombreArchivo = "registroBorradoFicherosIguales.txt";
        File f = new File(rutaDestino + "\\" + nombreArchivo);
        if (!f.exists()) {
            try {
                f.createNewFile();
            } catch (IOException e) {
                System.out.println("No ha sido posible crear el archivo: " + nombreArchivo);
            }
        }

        try (FileWriter fw = new FileWriter(f, true)) {
            File[] carpetas = rutaDestino.toFile().listFiles(File::isDirectory);
            Set<File> archivosAborrar = new HashSet<>();
            File archivo_a_borrar,dummy;
            for (File carpeta : carpetas) {
                File[] archivos = carpeta.listFiles();
                for (int i = 0; i < archivos.length - 1; i++) {
                	for (int j=i+1;j<archivos.length;j++) {
                    if (ComparacionArchivos.comparacionContenido(archivos[i], archivos[j])) {
                        archivo_a_borrar = ComparacionArchivos.compararFechas(archivos[i], archivos[j]);
                        archivosAborrar.add(archivo_a_borrar);
                    }
                }
            }
               
            }
            Iterator<File> iterator = archivosAborrar.iterator();
            while (iterator.hasNext()) {
                dummy = iterator.next();
                fw.write(dummy.getName() + " eliminado de la ruta " + dummy.getAbsolutePath() + " porque ya existe un archivo con el mismo contenido\n");
                dummy.delete();
            }
        } catch (IOException e) {
            System.out.println("No ha sido posible escribir en el archivo: " + nombreArchivo);
        }
        return true;
    }
}
