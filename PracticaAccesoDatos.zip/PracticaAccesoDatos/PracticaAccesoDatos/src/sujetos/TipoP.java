package sujetos;

public enum TipoP {
	habitual,
	esporadico,
	emergencia
}
