package archivos;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;

public class AnalisisArchivos {
	public static byte[] bytesDelArchivo(File f) {
		long length= f.length();
		byte[] b= new byte[(int)length];
		return b;
	}
	public static boolean comparacionContenido(File f1, File f2) {
		byte[] b1= bytesDelArchivo(f1);
		byte[] b2= bytesDelArchivo(f2);
		
		if(b1.length!=b2.length) return false;
		
		for(int i=0; i<b1.length;i++) {
			if(b1[i]!=b2[i]) return false;
		}
		
		return true;
	}

	public static File compararFechas(File f1, File f2) {
		FileTime t1;
		FileTime t2;
		try {
			t1 = (FileTime) Files.getAttribute(Paths.get(f1.getAbsolutePath()), "creationTime");
			t2 = (FileTime) Files.getAttribute(Paths.get(f2.getAbsolutePath()), "creationTime");
			if(t1.compareTo(t2)<0) return f1;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return f2;
	}
	public static boolean tipoArchivo(File f) {
		if(extension(f).equals(".dat") || extension(f).equals(".xml") || extension(f).equals(".txt")) return true;
		return false;
	}
	public static String extension(File f) {
		return f.getName().toLowerCase().substring(f.getName().lastIndexOf("."));
	}
}
