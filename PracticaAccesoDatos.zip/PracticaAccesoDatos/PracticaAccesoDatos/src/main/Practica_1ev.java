package main;
import archivos.*;

public class Practica_1ev {

    public static void main(String[] args) {
        String rutaCarpetaCompartida = "C:\\Users\\super\\OneDrive\\Escritorio\\archivosEjemplo";
        String rutaNueva=Reorganizacion.carpetaReubicacion(rutaCarpetaCompartida);
        Reorganizacion.crearCarpetas(rutaNueva, rutaCarpetaCompartida);
    }
}