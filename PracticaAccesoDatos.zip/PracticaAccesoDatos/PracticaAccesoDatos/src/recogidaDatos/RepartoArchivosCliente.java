package recogidaDatos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

import archivos.AnalisisArchivos;
import sujetos.Cliente;

public class RepartoArchivosCliente {
	public static void repartoDeClientes(File f) {
		ArrayList<ArrayList<Cliente>> clientes= new ArrayList<ArrayList<Cliente>>();
		File[] archivosClientes= f.listFiles();
		for(File archivo: archivosClientes) {
			if(AnalisisArchivos.extension(f).equals(".dat")) {
				clientes.add(clienteDat(archivo));
			}
			else if(AnalisisArchivos.extension(f).equals(".xml")) {
				
			}
			else if(AnalisisArchivos.extension(f).equals(".txt")) {
				
			}
		}
		
	}
	
	public static ArrayList<Cliente> clienteDat(File f) {
		Cliente cliente;
		int c;
		ArrayList<Cliente> clientes= new ArrayList<Cliente>();
		try {	
			ObjectInputStream is= new ObjectInputStream(new FileInputStream(f));
			while((c=is.read())!=-1) {
				cliente =(Cliente) is.readObject();
				clientes.add(cliente);
			}
			is.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return clientes;
	}
	public static ArrayList<Cliente> clienteTxt(File f){
		Cliente cliente;
		String str;
		ArrayList<Cliente> clientes= new ArrayList<Cliente>();
		try {
			BufferedReader br= new BufferedReader(new FileReader(f));
			while((str= br.readLine())!=null) {
				String[] atributos= str.split(";");
				for(int i=0; i<atributos.length;i++) {
					if(atributos[i].subSequence(0, atributos[i].lastIndexOf(":"))
				}
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
