package sujetos;

import java.io.Serializable;

public enum TipoCliente implements Serializable {
	vip,
	habitual,
	normal;

	
	
}
