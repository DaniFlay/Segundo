package archivos;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Scanner;

import registros.Registro;

public class Reorganizacion {
	public static String carpetaReubicacion(String rutaCarpetaCompartida) {
        Scanner sc = new Scanner(System.in);
        String ruta;
        do {
            System.out.println("Introduce la ruta para la reubicación de los archivos: ");
            ruta = sc.nextLine();
            if (ruta.isEmpty()) {
                System.out.println("Debes introducir una ruta.");
            }
        } while (ruta.isEmpty());
        sc.close();
        return ruta;
    }

    public static void crearCarpetas(String ruta, String rutaAntigua) {
        String[] nombresCarpetas = {"clientes", "empleados", "sucursales", "pedidos", "detalleDeLosPedidos", "productos", "proveedores"};
        for (String nombreCarpeta : nombresCarpetas) {
            File f = new File(ruta + "\\" + nombreCarpeta);
            if (!f.exists()) {
                f.mkdirs();
            }
        }
        
        analisisCarpeta(ruta, rutaAntigua);
    }

    public static void analisisCarpeta(String ruta, String rutaAntigua) {
        ArrayList<File> files = new ArrayList<>();
        File f = new File(rutaAntigua);
        if (f.exists()) {
            File[] archivos = f.listFiles();
            for (File archivo : archivos) {
                if (archivo.isDirectory()) {
                    analisisCarpeta(ruta, archivo.getAbsolutePath());
                } else if (archivo.isFile()) {
                    if (AnalisisArchivos.tipoArchivo(archivo)) {
                        files.add(archivo);
                    }
                }
            }
            copiaArchivos(files, ruta);
        }
    }

    public static void copiaArchivos(ArrayList<File> files, String ruta) {
        String[] nombresCarpetas = {"clientes", "empleados", "sucursales", "productos", "proveedores"};
        String[] nombresArchivos = {"cliente", "empleado", "sucursal", "producto", "proveedor"};

        File registroCopiaFicheros = new File(ruta + "\\registroCopiaFicheros.txt");
        registroCopiaFicheros.getParentFile().mkdirs();

        for (File file : files) {
            String fileName = file.getName().toLowerCase();
            String destinationPath = ruta;
            String folder = "";
            for (String nombreArchivo : nombresArchivos) {
                if (fileName.contains(nombreArchivo)) {
                    for (int i = 0; i < nombresCarpetas.length; i++) {
                        if (nombresCarpetas[i].contains(nombreArchivo)) {
                            folder = nombresCarpetas[i];
                        }
                    }
                    destinationPath += "\\" + folder + "\\" + file.getName();
                    break;
                }
            }

            if (fileName.contains("pedido")) {
                destinationPath += fileName.contains("detalle") ? "\\detalleDeLosPedidos" : "\\pedidos";
            }

            File destinationFile = new File(destinationPath);
            Path rutaOrigen = Paths.get(file.getAbsolutePath());

            try {
                Path rutaDestino;
                if (destinationFile.exists()) {
                    String r = cambioDelNombre(destinationFile);
                    rutaDestino = Paths.get(r);
                } else {
                    rutaDestino = Paths.get(destinationFile.getAbsolutePath());
                }

                Files.copy(rutaOrigen, rutaDestino, StandardCopyOption.REPLACE_EXISTING);
                Registro.registroCopia(registroCopiaFicheros.getAbsolutePath(), destinationFile, rutaOrigen, rutaDestino);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Registro.registroBorrado(Paths.get(ruta));
    }
    public static String cambioDelNombre(File rutaExistente) {
        String nombreArchivo = rutaExistente.getName();
        String nombreSinExtension = nombreArchivo.substring(0, nombreArchivo.lastIndexOf('.'));
        String extension = nombreArchivo.substring(nombreArchivo.lastIndexOf('.'));
        int count = 1;
        Path ruta = rutaExistente.toPath();

        while (Files.exists(ruta)) {
            String nombreNuevo = nombreSinExtension + '_' + count + extension;
            ruta = Paths.get(nombreNuevo);
            count++;
        }
        return ruta.toString();
    }
}
