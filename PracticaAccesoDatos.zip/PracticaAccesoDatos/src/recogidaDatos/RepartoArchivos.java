package recogidaDatos;

import java.io.File;

public class RepartoArchivos {
	public static void LeerDirectorios(File f) {
		File[] directorios= f.listFiles();
		for(File directorio: directorios) {
			if(directorio.getName().toLowerCase().contains("cliente")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("pedido")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("detalle")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("empleado")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("producto")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("proveedor")) {
				
			}
			else if(directorio.getName().toLowerCase().contains("sucursal")) {
				
			}
		}
	}

}
