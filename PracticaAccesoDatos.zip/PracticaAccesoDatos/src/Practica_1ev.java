import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Scanner;

public class Practica_1ev {

	public static void main(String[] args) {
		String rutaCarpetaCompartida="C:\\Users\\EstudianteDAM204\\Desktop\\CarpetaCompartida";
		carpetaReubicacion(rutaCarpetaCompartida);

	}

	/**
	 * @return
	 */
	public static int carpetaReubicacion(String rutaCarpetaCompartida) {
		int exito=0;
		String s="",ruta="";
		while(exito==0) {
			Scanner sc= new Scanner(System.in);
			System.out.println("Introduce la ruta para la reubicación de los archivos: ");
			ruta=sc.nextLine();
			if(ruta.equals(s)) {
				
				System.out.println("Debes introducir una ruta!");
			}
			else {
				exito=1;
			}
		}
		crearCarpetas(ruta, rutaCarpetaCompartida);
		return exito;
	}
	
	/**
	 * @param ruta
	 * @return exito
	 */
	public static int crearCarpetas(String ruta, String rutaAntigua) {
		int exito=0;
		String[] nombresCarpetas= {"clientes","empleados","sucursales","pedidos","detalleDeLosPedidos","productos","proveedores"};
		for(int i=0; i<nombresCarpetas.length;i++) {
			File f= new File(ruta+"\\"+nombresCarpetas[i]);
			if(!f.exists()) {
				f.mkdirs();
			}
		}
		analisisCarpeta(ruta,rutaAntigua);
		return exito;
	}
	public static int analisisCarpeta(String ruta,String rutaAntigua) {
		int q= 0;
		ArrayList<File> files= new ArrayList<File>();
		File f= new File(rutaAntigua);
		if(f.exists()) {
			File[] archivos= f.listFiles();
			for(int i=0;i<archivos.length;i++) {
				if(archivos[i].isDirectory()) {
					analisisCarpeta(ruta,archivos[i].getAbsolutePath());
				}
				else if(archivos[i].isFile()) {
					if(archivos[i].getName().substring(archivos[i].getName().lastIndexOf('.')).contains(".dat")||archivos[i].getName().substring(archivos[i].getName().lastIndexOf('.')).contains(".xml")||archivos[i].getName().substring(archivos[i].getName().lastIndexOf('.')).contains(".txt")) {
						files.add(archivos[i]);
					}
				}
			}
			copiaArchivos(files,ruta);
		}
		return q;
	}
	public static int copiaArchivos(ArrayList<File> files, String ruta) {
	    int q = 0;
	    String[] nombresCarpetas2={"clientes","empleados","sucursales","productos","proveedores"};
	    String[] nombresCarpetas = {"cliente", "empleado", "sucursal", "producto", "proveedor"};

	    File registroCopiaFicheros = new File(ruta + "\\registroCopiaFicheros.txt");
	    Path rutaOrigen, rutaDestino;

	    try {
	        if (!registroCopiaFicheros.exists()) {
	            registroCopiaFicheros.createNewFile();
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    for (File file : files) {
	        String fileName = file.getName().toLowerCase();
	        String destinationPath = ruta;
	        String folder="";
	        for (String nombreCarpeta : nombresCarpetas) {
	            if (fileName.contains(nombreCarpeta)) {
	            	for(int i=0;i<nombresCarpetas2.length;i++) {
	            		if(nombresCarpetas2[i].contains(nombreCarpeta)) {
	            			folder= nombresCarpetas2[i];
	            		}
	            	}
	                destinationPath += "\\" + folder + "\\" + file.getName();
	                
	                break;
	            }
	            
	        }

	        if (fileName.contains("pedido")) {
	            destinationPath += fileName.contains("detalle") ? "\\detalleDeLosPedidos" : "\\pedidos";
	        }

	        File destinationFile = new File(destinationPath);
	        rutaOrigen = Paths.get(file.getAbsolutePath());

	        try {
	            if (destinationFile.exists()) {
	                String r = cambioDelNombre(destinationFile);
	                rutaDestino = Paths.get(r);
	            } else {
	                rutaDestino = Paths.get(destinationFile.getAbsolutePath());
	            }

	            Files.copy(rutaOrigen, rutaDestino, StandardCopyOption.REPLACE_EXISTING);
	            registroCopia(registroCopiaFicheros.getAbsolutePath(), destinationFile, rutaOrigen, rutaDestino);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	    

	    return q;
	}
	public static int registroBorrado(Path rutaDestino) {
		String nombreArchivo="registroBorradoFicherosIguales.txt";
		File f= new File(rutaDestino+"\\"+nombreArchivo);
		if(!f.exists()) {
			try {
				f.createNewFile();
			} catch (IOException e) {
				System.out.println("No ha sido posible crear el archivo: "+nombreArchivo);
			}
		}
		try {
			FileWriter fw= new FileWriter(f,true);
		} catch (IOException e) {
			System.out.println("No ha sido posible escribir en el archivo: "+nombreArchivo);
		}
		File[] carpetas= rutaDestino.toFile().listFiles();
		int index=0;
		for(File carpeta: carpetas) {
			File[] archivos= carpeta.listFiles();
			for(int i=0; i<archivos.length;i++) {
				if(FileUtils)
			}
		}
		
	}
	
	public static String cambioDelNombre(File rutaExistente) {
		String nombreArchivo= rutaExistente.getName();
		String nombreSinExtension= nombreArchivo.substring(0, nombreArchivo.lastIndexOf('.'));
		String extension= nombreArchivo.substring(nombreArchivo.lastIndexOf('.'));
		int count=1;
		Path ruta= rutaExistente.toPath();
		
		while(Files.exists(ruta)) {
			String nombreNuevo= nombreSinExtension+'_'+count+extension;
			ruta= ruta.resolveSibling(nombreNuevo);
			count++;
		}
		return ruta.toString();
		
	}
	public static int registroCopia(String rutaArchivoRegistro, File archivo, Path rutaOrigen, Path rutaDestino) {
		int i=0;
		try {
			FileWriter fw= new FileWriter(rutaArchivoRegistro,true);
			fw.write(archivo.getName()+" copiado de "+rutaOrigen.toString()+" a "+rutaDestino.toString()+"\n");
			fw.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		return i;
	}

}
