package ejemplosUnidadDosAAD;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EscribirLeerFicheroBytes {

	public static void main(String[] args) {
		File f = new File("C:\\Users\\EstudianteDAM204\\Desktop\\ficheroBytes.dat");

		FileOutputStream fileout;
		try {
			fileout = new FileOutputStream(f, true);
		

		FileInputStream filein = new FileInputStream(f);

		int i;
		for (i = 1; i < 100; i++) {
			fileout.write(i);
		}
		fileout.close();
		while((i=filein.read())!=-1) {
			System.out.println(i);
		}
		filein.close();
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
