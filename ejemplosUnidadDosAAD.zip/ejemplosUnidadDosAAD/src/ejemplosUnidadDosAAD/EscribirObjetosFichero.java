package ejemplosUnidadDosAAD;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class EscribirObjetosFichero {

	public static void main(String[] args) {
		Alumno alumno;
		Random rand= new Random();
		File f = new File("C:\\Users\\EstudianteDAM204\\Desktop\\ficheroAlumnos.dat");
		try {
			FileOutputStream ficheroOS= new FileOutputStream(f,true);
			ObjectOutputStream objetosOS= new ObjectOutputStream(ficheroOS);
		
			ArrayList<String> nombres= new ArrayList<String>(Arrays.asList("Pedro","Miguel","Manuel","Alba"));
			ArrayList<String> ciclos= new ArrayList<String>(Arrays.asList("DAM","MED","PRO","INF"));
			
			for(int i=0;i<ciclos.size();i++) {
				int curso= rand.nextInt(2);
				alumno= new Alumno(nombres.get(i),ciclos.get(i),curso);
				objetosOS.writeObject(alumno);
			}
			objetosOS.close();
		}catch(IOException e) {
			
		}

	}

}
