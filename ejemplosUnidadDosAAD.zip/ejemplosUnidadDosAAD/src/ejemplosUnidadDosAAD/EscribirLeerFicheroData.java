package ejemplosUnidadDosAAD;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EscribirLeerFicheroData {

	public static void main(String[] args) {
		File f = new File("C:\\Users\\EstudianteDAM204\\Desktop\\FicheData.dat");
		try {
			DataOutputStream dataOS= new DataOutputStream(new FileOutputStream(f));
			DataInputStream dataIS= new DataInputStream(new FileInputStream(f));
			String nombres[]= {"Ana", "Paco", "Pepe"};
			int edades[] = {15,21,74};
			for (int i=0;i<edades.length;i++) {
				dataOS.writeUTF(nombres[i]);
				dataOS.writeInt(edades[i]);
				
			}
			dataOS.close();
			String nombre;
			int edad;
			while(true) {
				nombre= dataIS.readUTF();
				edad= dataIS.readInt();
				System.out.println("Nombre: "+nombre+", edad: "+edad);
			}
		}catch(FileNotFoundException e) {
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}

}
