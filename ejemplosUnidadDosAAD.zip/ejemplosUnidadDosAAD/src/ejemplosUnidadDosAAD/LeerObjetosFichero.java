package ejemplosUnidadDosAAD;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class LeerObjetosFichero {

	public static void main(String[] args) {
		Alumno alumno;
		File f= new File("C:\\Users\\EstudianteDAM204\\Desktop\\ficheroAlumnos.dat");
		try {
			
			ObjectInputStream objetoIS=new ObjectInputStream(new FileInputStream(f));
		
			int i=1;
			while(true) {
				alumno=(Alumno) objetoIS.readObject();
				System.out.println("Alumno"+i+":");
				System.out.println("Nombre: "+alumno.getNombre()+", Ciclo: "+alumno.getCiclo()+", Curso: "+alumno.getCurso());
				i++;
			}
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		
	}

}
