package ejemplosUnidadDosAAD;

import java.io.Serializable;

public class Alumno implements Serializable {
	private String nombre;
	private String ciclo;
	private int curso;
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getCiclo() {
		return ciclo;
	}
	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}
	public int getCurso() {
		return curso;
	}
	public void setCurso(int curso) {
		this.curso = curso;
	}
	public Alumno(String nombre, String ciclo, int curso) {
		this.nombre = nombre;
		this.ciclo = ciclo;
		this.curso = curso;
	}
	public Alumno() {

	}
	
	
}
