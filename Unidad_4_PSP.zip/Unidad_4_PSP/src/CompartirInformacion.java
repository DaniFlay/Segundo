
public class CompartirInformacion {

	public static void main(String[] args) {
		Contador cont= new Contador(280);
		HiloA a= new HiloA("HiloA",cont);
		HiloA b= new HiloA("HiloB",cont);
		
		a.start();
		b.start();

	}

}
